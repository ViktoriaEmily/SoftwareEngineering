package com.company;
public class Bank
{
    private String bankName;  // the name field should be no more than 15 characters long.
    private String bankManager;  // the name of the bank Manager, no more than 20 characters long.
    private double interestRate; // is a percentage so must be between 0 and 100 inclusive.

    /**
     * Constructor for objects of class Bank
     */
    public Bank(String bankName, String bankManager, double interestRate)
    {
        // initialise instance variables
        if ( bankName.length() <=15 )
        {
            this.bankName = bankName;
        }
        else
            this.bankName = bankName.substring(0,15);

        if ( bankManager.length() <=20 )
        {
            this.bankManager = bankManager;
        }
        else
            this.bankManager = bankManager.substring(0,20);

        if ((interestRate >= 0 ) && (interestRate <= 100))
        {
            this.interestRate = interestRate;
        }
        else
            this.interestRate = 0;
    }
    /**
     * @return the bank name.
     */
    public String getBankName()
    {
        return bankName;
    }
    public void setBankName(String bankName)
    {
        if ( bankName.length() <=15 )
        {
            this.bankName = bankName;
        }
    }
    /**
     * @return the bank manager's name.
     */
    public String getBankManager()
    {
        return bankManager;
    }
    public void setBankManager(String bankManager)
    {
        if ( bankManager.length() <=20 )
        {
            this.bankManager = bankManager;
        }
    }
    /**
     *
     * @return interest
     */
    public double getInterestRate()
    {
        return interestRate;
    }
    public void setInterestRate(double interestRate)
    {
        if ((interestRate >= 0 ) && (interestRate <= 100))
        {
            this.interestRate = interestRate;
        }
    }

    /**
     * @return the string version of the bank object
     */
    public String toString()
    {
        return ( "Name : " +bankName + "   Bank Manager: " + bankManager + "  Interest Rate: "+ interestRate);
    }

}


