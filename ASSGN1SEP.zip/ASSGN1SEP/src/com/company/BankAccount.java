package com.company;

/**
 * This class simulates a bank account. Each bank account has a customer associated with it.
 * We can deposit and withdraw money from the bank account and calculate compound interest.
 */
public class BankAccount
{
    private int accNumber;            // should be 6 digits, i.e. between 100000 and 999999
    private String accountName;       // should be no more than 20 characters
    private String accountAddress;   // should be no more than 30 characters
    private double balance;           // The balance in the account. This must be non-negative (i.e. deposit accounts only)

    private Bank holdingBank;         // This is the bank that the account is in, e.g. AIB, Bank of Ireland.


    /**
     * Constructor for objects of class BankAccount - creates an account object
     */
    public BankAccount(int accNumber, String accountName, String accountAddress, double balance,
                       Bank holdingBank)
    {
        if ( (accNumber >= 100000) && ( accNumber <=999999) )
        {
            this.accNumber = accNumber;
        }
        else
        {
            this.accNumber = 100000;
        }

        if (accountName.length() <= 20)
        {
            this.accountName = accountName;
        }
        else
        {
            this.accountName = accountName.substring(0,20);
        }

        if (accountAddress.length() <= 30)
        {
            this.accountAddress = accountAddress;
        }
        else
        {
            this.accountAddress = accountAddress.substring(0,30);
        }

        if (balance >= 0 )
        {
            this.balance = balance;
        }
        else
        {
            this.balance = 0;
        }


        this.holdingBank = holdingBank;


    }


    /**
     * @return the accNumber
     */
    public int getAccNumber()
    {
        return accNumber;
    }

    /**
     * sets the accNumber field
     */
    public void setAccNumber(int accNumber)
    {
        if ( (accNumber >= 100000) && ( accNumber <=999999) )
        {
            this.accNumber = accNumber;
        }
    }

    /**
     * @return the member's name
     */
    public String  getAccountName()
    {
        return accountName;
    }

    /**
     * sets the members name - check the data is valid.
     */
    public void  setAccountName(String accountName)
    {
        if (accountName.length() <= 20)
        {
            this.accountName = accountName;
        }
    }

    /**
     * @return the member's address
     **/
    public String getAccountAddress()
    {
        return accountAddress;
    }


    /**
     * set the member's address - check that value is valid
     */
    public void setAccountAddress( String accountAddress)
    {
        if (accountAddress.length() <= 30)
        {
            this.accountAddress = accountAddress;
        }
    }


    /**
     * @return the member's balance
     **/
    public double getBalance()
    {
        return balance;
    }


    /**
     * set the member's balance - check value is valid
     */
    public void setBalance( double balance)
    {
        if (balance >= 0 )
        {
            this.balance = balance;
        }

    }

    public Bank getHoldingBank()
    {
        return holdingBank;
    }

    public void setHoldingBank(Bank holdingBank)
    {
        this.holdingBank = holdingBank;
    }

    /**
     * this method calculates interest by using compound interest each month
     * based on the annual rate.
     * @return the new balance.
     **/
    public double projectNewBalance(int numberYears)
    {
        double newBalance=  this.balance;
        double rate  = holdingBank.getInterestRate();
        if (numberYears >=0 )
        {
            for (int i = 1; i<=numberYears; i++)
            {
                newBalance += (rate*newBalance)/100.0;
            }

            return newBalance;
        }
        else
            return -1;
    }

    /**
     * this method calculates interest by using compound interest each year
     * based on the annual rate.
     * @return the interest that would be
     **/
    public int projectHowLong (double target)
    {
        if (target >= this.balance)
        {
            double newBalance=  this.balance;
            double rate  = holdingBank.getInterestRate();

            int numYears= 0;  //
            while ( newBalance < target)
            {
                newBalance += (rate*newBalance)/100.0;
                numYears++;
            }
            return numYears;
        }
        else
        {
            return -1;
        }
    }




    public double extendedProjectBalance(int numberYears)
    {

        if (numberYears >=0 )
        {
            double newBalance=  this.balance;
            double rate  = holdingBank.getInterestRate();

            for (int i = 1; i<=numberYears; i++)
            {
                newBalance += (rate*newBalance)/100.0;
                System.out.println("After year " + (i) + " the projected balance is: " + toTwoDecimalPlaces(newBalance));
            }

            return newBalance;
        }
        else
        {
            return -1;
        }
    }

    /**
     * Withdraw money. Money can only withdrawn if there are sufficient funds (i.e. account cannot be overdrawn)
     * and the amount must be non-negative
     * @param amount of money to be withdrawn.
     */
    public void withdraw(double amount)
    {
        if ( (amount <= balance) && (amount >=0) )
        {
            balance -= amount;
        }
        else if (amount > balance)
        {
            System.out.println("You do not have sufficient funds to withdraw :"+ amount+".");
        }
        else
        {
            System.out.println("You must withdraw a positive amount");
        }

    }
    /**
     * Lodge money. You can lodge any positive amount
     * @param amount of money to be lodged.
     */
    public void lodge(double amount)
    {
        if (amount > 0)
        {
            balance += amount;
        }
        else
        {
            System.out.println("You cannot lodge a negative amount");
        }
    }

    /**
     * @return true if the bankAccount object will reach the target within 5 years at the current interest rate,
     * false otherwise.
     */
    public boolean reachTarget(double target)
    {
        if (target >= this.balance)
        {
            return ( projectNewBalance(5) >=target );
        }
        else
            return false;
    }

    /**
     * This method categorises the account. Depending on the balance it will be
     * 0 -> <100 ->    Category 1
     * 100 -> <500 ->  Category 2
     * 500 -> <1000 -> Category 3
     * >= 1000->      Category 4
     * @return the category as defined above. Also print the category to the screen.
     */
    public int getAccountCategory()
    {
        if ( balance <100 )
        {
            System.out.println ("This account is a Category one account");
            return 1;
        }
        else if (balance <500 )
        {
            System.out.println ("This account is a Category two account");
            return 2;
        }
        else if (balance <1000)
        {
            System.out.println ("This account is a Category three account");
            return 3;
        }
        else
            System.out.println ("This account is a Category four account");
        return 4;
    }

    /**
     * @return the argument but now to two decimal places.
     */
    private  double toTwoDecimalPlaces( double num)
    {
        return (int) (num *100 ) /100.0;
    }

    /**
     * @return a string version of the BankAccount object
     */
    public String toString()
    {
        return ("Account number : " + accNumber + " " + " Account Name :"  + accountName + ",  Account Address :" + accountAddress +  "\nAccount balance : "+
                toTwoDecimalPlaces(balance)    + "\n" +  holdingBank.toString() + "\n");
    }
}

