package com.company;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

//get and set methods together
//Repeat gor bankB
//bankC
//test toString
import static org.junit.jupiter.api.Assertions.*;

public class BankTest {
    //SETTING UP BANK
    Bank bankA , bankB , bankC;



    @BeforeEach
    public void setUp() throws Exception {
        //ESTABLISHING UP BANK
        bankA= new Bank("bankA","Alice",.4);
        bankB=new Bank("bankB","Brian",.6);
    }

    @AfterEach
    void tearDown() throws Exception {
        bankA = null;
        bankB = null;
        bankC = null;
    }

    @Test
    public void testBankAIsNotEqualToNull() {
        assertNotNull(bankA,"Bank");
    }
    @Test
    public void testBankCIsNull() {
        assertNull(bankC, "");
    }

    @Test
    void getBankNameTest() {
       assertEquals("bankA", bankA.getBankName());
    }

    @Test
    void getBankManagerTest() {
        assertEquals("Alice", bankA.getBankManager());
    }

    @Test
    void getInterestRateTest() {
        assertEquals(.4, bankA.getInterestRate());
    }
    @Test
    void setBankNameTest() {
        bankA.setBankName("Bank of Ireland");
        assertEquals("Bank of Ireland", bankA.getBankName());
    }

    @Test
    void getBankManager() {
    }

    @Test
    void setBankManager() {
    }

    @Test
    void getInterestRate() {

    }

    @Test
    void setInterestRateTest() {
        bankA.setInterestRate(.8);
        assertEquals(.8, bankA.getInterestRate());
    }

    @Test
    void testToString() {
    }
}