package com.company;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BankAccountTest {
Bank bankA;
    BankAccount bankAccount;

    @BeforeEach
    void setUp() throws Exception {
        bankA= new Bank("bankA","Alice",.4);
        bankAccount = new BankAccount( 44444, "Kelly", "New Ross", 100000, bankA);

    }

    @AfterEach
    void tearDown() {
        bankA= null;
        bankAccount= null;
    }

//do test assertnot null for bankAccount

    @Test
    void getAccNumber() {
        assertEquals();
    }

    @Test
    void setAccNumber() {
    }

    @Test
    void getAccountName() {
    }

    @Test
    void setAccountName() {
    }

    @Test
    void getAccountAddress() {
    }

    @Test
    void setAccountAddress() {
    }

    @Test
    void getBalance() {
    }

    @Test
    void setBalance() {
    }

    @Test
    void getHoldingBank() {
    }

    @Test
    void setHoldingBank() {
    }

    @Test
    void projectNewBalance() {
    }

    @Test
    void projectHowLong() {
    }

    @Test
    void extendedProjectBalance() {
    }

    @Test
    void withdraw() {
    }

    @Test
    void lodge() {
    }

    @Test
    void reachTarget() {
    }

    @Test
    void getAccountCategory() {
    }

    @Test
    void testToString() {
    }
}